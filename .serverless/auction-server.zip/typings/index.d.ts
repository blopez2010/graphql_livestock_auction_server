/// <reference path="globals/moment/index.d.ts" />
/// <reference path="globals/uuid/index.d.ts" />
/// <reference path="modules/sequelize-fixtures/index.d.ts" />
/// <reference path="modules/sequelize/index.d.ts" />
/// <reference path="modules/sequelize/v3/index.d.ts" />
