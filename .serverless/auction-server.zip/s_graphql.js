var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'merlin2010',
applicationName: 'myapp',
appUid: 'qnY8DC3SSj92YHSZxX',
tenantUid: 'GFlfdMyqX5X6GFFYRD',
deploymentUid: '0e2020da-846e-4c43-9e3a-363fb5677a6c',
serviceName: 'auction-server',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'auction-server-dev-graphql', timeout: 6}
try {
  const userHandler = require('./src/graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
