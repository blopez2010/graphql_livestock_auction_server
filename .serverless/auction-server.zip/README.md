# graphql_livestock_auction
Graphql learn and practicing
