module.exports = {
  itemsAttributes: [
    'id',
    'ownerId',
    'ordinal',
    'description',
    'externalIdentifier',
    'createdAt',
    'updatedAt',
    'eventId'
  ]
};